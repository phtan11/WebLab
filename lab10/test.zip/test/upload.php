<?php
    session_start();
    if(!isset($_POST['file-name']))
    {
        $_SESSION['error'] = 'please enter a valid name of file';
        header('Location: exercise1.php');
        die();
    }

    if(!isset($_FILES['file-data']))
    {
        $_SESSION['error'] = 'please take a your file';
        header('Location: exercise1.php');
        die();

    }
    // print_r($_POST); 
    // print_r($_FILES); 

    $f = $_FILES['file-data'];
    $name = $f['name'];
    $size = $f['size'];
    $tmp = $f['tmp_name'];
    $new_name = $_POST['file-name'];

    //check size
    if($size > 500*1024*1024){
        $_SESSION['error'] = 'This file is too large';
        header('Location: exercise1.php');
        die(    );
    }   


    $save_path = 'tantongteo/' . $new_name;
    


    $ext = pathinfo($name, flags: PATHINFO_EXTENSION);
    
    $supported_files = array('txt', 'doc', 'docx', 'xls', 'xlsx', 'jpg', 'png', 'mp3', 'mp4','pdf', 'rar', 'zip');
    if (!in_array($ext, $supported_files)){
        $_SESSION['error'] = 'this type of file is not supported by server!!';
        header('Location: exercise1.php');
        die();
    }
    //move file
    $root = $_SERVER['DOCUMENT_ROOT'];
    $fullpath = $root .   $save_path;
    if(move_uploaded_file($tmp,$fullpath )){
        $_SESSION['success'] = 'this file has been saved !!';
        header('Location: exercise1.php');
        die();

    }
    else{
        $_SESSION['error'] = 'CAnnot save the uploaded file!!';
        header('Location: exercise1.php');
        die();
    }
    echo $root;
?>  